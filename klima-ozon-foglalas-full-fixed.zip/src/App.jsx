import { useState } from 'react'

export default function App() {
  const [service, setService] = useState('klima')
  const [ozoneType, setOzoneType] = useState('auto')
  const [date, setDate] = useState('')

  const handleSubmit = () => {
    if (!date) return alert('Kérlek, válassz dátumot!')
    const szolg = service === 'ozon' ? `Ózonos fertőtlenítés (${ozoneType})` : 'Klímatisztítás'
    alert(`Sikeres foglalás:\nSzolgáltatás: ${szolg}\nIdőpont: ${date}`)
  }

  return (
    <div style={{ maxWidth: 400, margin: '2rem auto', fontFamily: 'Arial' }}>
      <h2>Foglalás</h2>

      <div>
        <label>
          <input
            type="radio"
            value="klima"
            checked={service === 'klima'}
            onChange={() => setService('klima')}
          /> Klímatisztítás
        </label>
        <br />
        <label>
          <input
            type="radio"
            value="ozon"
            checked={service === 'ozon'}
            onChange={() => setService('ozon')}
          /> Ózonos fertőtlenítés
        </label>
      </div>

      {service === 'ozon' && (
        <div style={{ marginLeft: '1rem' }}>
          <label>
            <input
              type="radio"
              value="auto"
              checked={ozoneType === 'auto'}
              onChange={() => setOzoneType('auto')}
            /> Autó
          </label>
          <br />
          <label>
            <input
              type="radio"
              value="epulet"
              checked={ozoneType === 'epulet'}
              onChange={() => setOzoneType('epulet')}
            /> Épület
          </label>
        </div>
      )}

      <div style={{ marginTop: '1rem' }}>
        <label>Dátum: <input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
      </div>

      <button onClick={handleSubmit} style={{ marginTop: '1rem' }}>Foglalás elküldése</button>
    </div>
  )
}
